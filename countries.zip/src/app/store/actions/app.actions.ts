import { Action } from "@ngrx/store";
import { Country } from "./../../models/country";

export enum EAppActions {
  GetCountries = "Get Countries",
  GetCountriesSuccess = "Get Countries Success",
  GetCountry = "Get Country",
  GetCountrySuccess = "Get Country Success"
}

export class GetCountries implements Action {
  public readonly type = EAppActions.GetCountries;
  constructor(public payload: string) {}
}

export class GetCountriesSuccess implements Action {
  public readonly type = EAppActions.GetCountriesSuccess;
  constructor(public payload: Country[]) {}
}

export class GetCountry implements Action {
  public readonly type = EAppActions.GetCountry;
  constructor(public payload: number) {}
}

export class GetCountrySuccess implements Action {
  public readonly type = EAppActions.GetCountrySuccess;
  constructor(public payload: Country) {}
}

export type AppActions =
  | GetCountries
  | GetCountry
  | GetCountriesSuccess
  | GetCountrySuccess;
