import { initialAppState } from "../state/app.state";
import { EAppActions, AppActions } from "../actions/app.actions";
import { AppState } from "./../state/app.state";

export const appReducers = (
  state = initialAppState,
  action: AppActions
): AppState => {
  switch (action.type) {
    case EAppActions.GetCountriesSuccess: {
      console.log(action.payload);
      return {
        ...state,
        countries: action.payload
      };
    }
    case EAppActions.GetCountrySuccess: {
      console.log(action.payload);
      return {
        ...state,
        country: action.payload.name,
        countryInfo: action.payload
      };
    }

    default: {
      return state;
    }
  }
};
