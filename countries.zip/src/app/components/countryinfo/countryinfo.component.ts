import { Component, Input } from "@angular/core";
import { Country } from "./../../models/country";

@Component({
  selector: "app-country-info",
  templateUrl: "./countryinfo.component.html",
  styleUrls: ["./countryinfo.component.css"]
})
export class CountryInfo {
  @Input() country: Country;
}
