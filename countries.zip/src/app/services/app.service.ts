import { map, filter, catchError, mergeMap } from "rxjs/operators";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Http, Headers, Response } from "@angular/http";
import { Country } from "./../models/country";

@Injectable({
  providedIn: "root"
})
export class AppService {
  private API_PATH = "https://restcountries.eu/rest/v2/region";
  private API_PATH2 = "https://restcountries.eu/rest/v2/alpha";

  constructor(private http: Http) {}

  getCountries(region) {
    console.log(region);
    return this.http.get(`${this.API_PATH}/${region}`);
  }

  getCountry(code) {
    return this.http.get(`${this.API_PATH2}/${code}`);
  }
}
