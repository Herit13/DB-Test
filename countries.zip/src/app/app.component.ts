import { Component, OnInit, ChangeDetectionStrategy } from "@angular/core";
import { Store, select } from "@ngrx/store";
import { MainAppState } from "./store/state/app.state";
import { take } from "rxjs/operators";
import { GetCountry, GetCountries } from "./store/actions/app.actions";
import {
  selectCountries,
  selectRegions,
  selectCountryInfo
} from "./store/selectors/app.selectors";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  title = "country-info";
  regions$ = this._store.select(selectRegions);
  countries$ = this._store.select(selectCountries);
  countryInfo$ = this._store.select(selectCountryInfo);

  constructor(private _store: Store<MainAppState>) {}

  onChangeRegion(value) {
    console.log(value);
    this._store.dispatch(new GetCountries(value));
  }
  onChangeCountry(value) {
    this._store.dispatch(new GetCountry(value));
  }

  ngOnInit(): void {
    // this._store.select(s => s.regions).subscribe(data => (this.genre = data))
  }
}
